import { Routes } from '@angular/router';

import { CategorydetailComponent } from '../categorydetail/categorydetail.component';
import { CategoryComponent } from '../category/category.component';
import { HomeComponent } from '../home/home.component';
import { ContactComponent } from '../contact/contact.component';
import { SearchresultComponent } from '../searchresult/searchresult.component';
import { RefreshComponent } from '../refresh/refresh.component';

export const routes: Routes = [
  { path: 'home',  component: HomeComponent },
  { path: 'categories',     component: CategoryComponent },
  { path: 'contactus',     component: ContactComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'categorydetail/:id',     component: CategorydetailComponent },
  { path: 'searchresult/:searchInput',     component: SearchresultComponent },
  { path: 'refresh',     component: RefreshComponent },
];