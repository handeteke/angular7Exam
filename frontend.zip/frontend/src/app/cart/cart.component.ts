import { Component, OnInit, Input, Inject } from '@angular/core';
import { SESSION_STORAGE, StorageService } from 'angular-webstorage-service';
import { User } from '../shared/user';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})


export class CartComponent implements OnInit {

  databaseUser;
  errMess;
  products:[];

  constructor(@Inject(SESSION_STORAGE) private storage: StorageService,
    private loginService: LoginService,
    @Inject('BaseURL') private BaseURL, ) {

  }

  ngOnInit() {
    this.getCurrentProducts();
    this.loginService.getUser(this.storage.get('user').id).subscribe((user) => {
      this.databaseUser = user
      console.log(this.databaseUser)
    }, (errmess) => {
      this.errMess = <any>errmess
      console.log(errmess)
    });
  }

  getCurrentProducts(){
    this.products = this.storage.get('user').cart
  }

  public delete(index) {
    console.log('this.databaseUser.cart[id]', this.databaseUser.cart[index]);
    this.databaseUser.cart.splice(index, 1);
    console.log(this.databaseUser)
    this.databaseUser.save()
      .subscribe(user => { 
        this.storage.set('user', user);
        this.getCurrentProducts();
        console.log(user); 
    });
  }


}
