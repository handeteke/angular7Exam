import { Component, OnInit, Inject } from '@angular/core';
import { Category } from '../shared/category';
import { CategoryService } from '../services/category.service'

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})

export class CategoryComponent implements OnInit {

  errMess: string;
  categories: Category[];

  constructor(private categoryService: CategoryService, @Inject('BaseURL') private BaseURL) { }

  ngOnInit() {
    this.categoryService.getCategories()
    .subscribe(cats => this.categories = cats,
        errmess => this.errMess = <any>errmess.message);
  }

}
