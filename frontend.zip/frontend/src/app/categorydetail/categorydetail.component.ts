import { Component, OnInit, Input, Inject } from '@angular/core';

import { CategoryService } from '../services/category.service';
import { ProductdetailComponent } from '../productdetail/productdetail.component';
import { Params, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Category } from '../shared/category';
import { Product } from '../shared/product';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SESSION_STORAGE, StorageService } from 'angular-webstorage-service';

export interface DialogData {
  product: Product;
}

@Component({
  selector: 'app-categorydetail',
  templateUrl: './categorydetail.component.html',
  styleUrls: ['./categorydetail.component.scss']
})
export class CategorydetailComponent implements OnInit {

  @Input()
  categoryInput: Category;
  errMess: string;
  category: Category;
  clicked = false;

  constructor(private categoryservice: CategoryService,
    private route: ActivatedRoute,
    private location: Location,
    public dialog: MatDialog,
    @Inject('BaseURL') private BaseURL,
    @Inject(SESSION_STORAGE) private storage: StorageService) {


  }

  ngOnInit() {
    const id = +this.route.snapshot.params['id'];

    this.categoryservice.getCategory(id).subscribe((cat) => {
      this.category = cat
      console.log(cat)
    }, (errmess) => {
      this.errMess = <any>errmess
      console.log(errmess)
    });
  }

  goBack(): void {
    this.location.back();
  }

  openProductDetailForm(product) {

    console.log('this.storage.get(user)', this.storage.get('user'));

    if (this.storage.get('user')) {
      const dialogRef = this.dialog.open(ProductdetailComponent, { width: '300px', height: '500px', data: product });
      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
      });
    }

  }

}
