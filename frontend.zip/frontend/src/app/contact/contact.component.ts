import { Component, OnInit, ViewChild, Inject  } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Feedback, ContactType } from '../shared/feedback';
import { User } from '../shared/user';
import { FeedbackService } from '../services/feedback.service';
import { SESSION_STORAGE, StorageService } from 'angular-webstorage-service';
import { AlertsService } from 'angular-alert-module';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {

  @ViewChild('fform') feedbackFormDirective;

  feedbackForm: FormGroup;
  feedback: Feedback;
  contactType = ContactType;
  user: User;

  feedbacks : Feedback[];
  errMess;
  lastId;

  formErrors = {
    'telnum': ''
  };

  validationMessages = {
    'telnum': {
      'required': 'Tel. number is required.',
      'pattern': 'Tel. number must contain only numbers.'
    }
  };

  constructor(private fb: FormBuilder, 
    private feedbackService: FeedbackService, 
    @Inject('BaseURL') private BaseURL,
    @Inject(SESSION_STORAGE) private storage: StorageService,
    private alerts: AlertsService) {
    this.createForm();
    this.getFeedbacks();
  }
  
  ngOnInit() {
    this.user = this.storage.get('user')
    this.alerts.setDefaults('timeout',5);
  }

  createForm() {
    this.feedbackForm = this.fb.group({
      telnum: ['', [Validators.required, Validators.pattern]],
      agree: false,
      contacttype: 'None',
      message: ''
    });

    this.feedbackForm.valueChanges
      .subscribe(data => this.onValueChanged(data));

    this.onValueChanged(); // (re)set validation messages now
  }

  onValueChanged(data?: any) {
    if (!this.feedbackForm) { return; }
    const form = this.feedbackForm;
    for (const field in this.formErrors) {
      if (this.formErrors.hasOwnProperty(field)) {
        // clear previous error message (if any)
        this.formErrors[field] = '';
        const control = form.get(field);
        if (control && control.dirty && !control.valid) {
          const messages = this.validationMessages[field];
          for (const key in control.errors) {
            if (control.errors.hasOwnProperty(key)) {
              this.formErrors[field] += messages[key] + ' ';
            }
          }
        }
      }
    }
  }

  onSubmit() {
    let user: User;
    user = this.storage.get('user')

    this.feedback ={
      "id" : this.lastId+1,
      "from": user,
      "telnum": "",
      "message": ""
    }

    if(user){
      console.log(user);
      this.feedback.telnum =  this.feedbackForm.controls.telnum.value;
      this.feedback.message =  this.feedbackForm.controls.message.value;
  
      this.feedbackService.postFeedback(this.feedback);
  
      console.log(this.feedback);
      this.feedbackFormDirective.resetForm();
    }else{
      console.log("dfdsfvdf");
      this.alerts.setMessage('Please enter a valid amount','warn');
    }
    this.getFeedbacks();
  }

  getFeedbacks(){
    this.feedbackService.getFeedbacks()
    .subscribe(feedbacks => {
      this.feedbacks = feedbacks
      this.lastId = this.feedbacks[this.feedbacks.length-1].id
    },errmess => this.errMess = <any>errmess.message);

  }

}
