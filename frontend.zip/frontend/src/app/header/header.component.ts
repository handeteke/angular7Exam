import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { LoginComponent } from '../login/login.component';
import { CartComponent } from '../cart/cart.component';
import { User } from '../shared/user';
import { Inject, Injectable } from '@angular/core';
import { SESSION_STORAGE, StorageService } from 'angular-webstorage-service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CategoryService } from '../services/category.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  authenticatedUser = null;
  username = '';
  searchForm: FormGroup;

  constructor(@Inject(SESSION_STORAGE) private storage: StorageService,
    public dialog: MatDialog,
    private fb: FormBuilder,
    @Inject('BaseURL') private BaseURL,
    private router: Router) {
    this.createForm();


  }

  ngOnInit() {
    if (this.storage.get('user')) {
      this.storage.remove('user')
    }
  }
  createForm() {
    this.searchForm = this.fb.group({
      searchInput: [''],
    });
  }

  openLoginForm() {
    const dialogRef = this.dialog.open(LoginComponent, { width: '500px', height: '300px' });

    dialogRef.afterClosed().subscribe(result => {

      if (result) {
        console.log('The dialog was closed');
        this.authenticatedUser = result;
        this.storage.set('user', this.authenticatedUser);
        this.username = this.authenticatedUser.username;

        console.log('this.storage.get(user)');
        console.log(this.storage.get('user'));
      } else {
        this.authenticatedUser = null;
        this.username = '';
        this.storage.set('user', null);
      }


    });
  }

  showCart() {
    console.log('this.storage.get(user)', this.storage.get('user'));

    const dialogRef = this.dialog.open(CartComponent, { width: '600px', height: '600px', data: this.storage.get('user') });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  logout() {
    this.authenticatedUser = null;
    this.storage.set('user', null);
    this.username = '';
  }

  route() {
    //this.router.navigate(['/searchresult', this.searchForm.controls.searchInput.value])
    
    this.router.navigateByUrl('/refresh', { skipLocationChange: true }).then(() =>
      this.router.navigate(['/searchresult', this.searchForm.controls.searchInput.value]));
  }


}

