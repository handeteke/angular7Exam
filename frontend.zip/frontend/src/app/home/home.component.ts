import { Component, OnInit, Inject } from '@angular/core';

import { Product } from '../shared/product';
import { Promotion } from '../shared/promotion';
import { PromotionService } from '../services/promotion.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  promotion: Promotion;
  promotions: Promotion[];
  errMess;

  constructor(private promotionservice: PromotionService,
    @Inject('BaseURL') private BaseURL) { }

  ngOnInit() {
    this.promotionservice.getPromotions()
      .subscribe(p => this.promotions = p,
        errmess => this.errMess = <any>errmess.message);
  }

}
