import { Component, OnInit, Input, Inject, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { LoginService } from '../services/login.service';
import { User } from '../shared/user';
import { assertDataInRangeInternal } from '@angular/core/src/render3/util';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  @ViewChild('fform') loginFormDirective;

  user = { email: '', password: '', remember: false }; //UNUTMA!!!!!!!!!!!!!!!!!!!!!
  errMess = null;

  authenticatedUser: User;
  allUsers: User[];

  loginForm: FormGroup;

  formErrors = {
    'password': '',
    'email': '',
    'remember': false
  };

  validationMessages = {
    'password': {
      'required': 'Password is required.',
      'minlength': 'Password must be at least 2 characters long.',
      'maxlength': 'Password cannot be more than 25 characters long.'
    },
    'email': {
      'required': 'Email is required.',
      'email': 'Email not in valid format.'
    },
  };


  constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<LoginComponent>,
    private loginService: LoginService,
    @Inject('BaseURL') private BaseURL) {

    
  }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.loginForm = this.fb.group({
      password: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25)]],
      email: ['', [Validators.required, Validators.email]],
      remember: [false]
    });

    this.loginForm.valueChanges
      .subscribe(data => this.onValueChanged(data));

    this.onValueChanged(); // (re)set validation messages now
  }

  onValueChanged(data?: any) {
    if (!this.loginForm) { return; }
    const form = this.loginForm;
    for (const field in this.formErrors) {
      if (this.formErrors.hasOwnProperty(field)) {
        // clear previous error message (if any)
        this.formErrors[field] = '';
        const control = form.get(field);
        if (control && control.dirty && !control.valid) {
          const messages = this.validationMessages[field];
          for (const key in control.errors) {
            if (control.errors.hasOwnProperty(key)) {
              this.formErrors[field] += messages[key] + ' ';
            }
          }
        }
      }
    }
  }

  onSubmit() {
    this.user = this.loginForm.value;

    //this.loginFormDirective.resetForm();

    console.log('User: ', this.user);

    this.loginService.getUsers().subscribe((res) => {
      if (res) {
        console.log(res);
        this.allUsers = res;
        this.getUser();
      } else {
        console.log('EMPTY allUsers!');
      }
    }, (errmess) => {
      this.errMess = <any>errmess.message
    });
  }

  getUser() {
    let id = -1;

    for (let u of this.allUsers) {
      if (u.email == this.user.email && u.password == this.user.password) {
        id = u.id;
        console.log('id', id)
      }
    }

    this.loginService.getUser(id).subscribe((user) => {
      this.authenticatedUser = user
      console.log(user)
      this.dialogRef.close(user);
    }, (errmess) => {
      this.errMess = <any>errmess
      console.log(errmess)
    });

  }

}
