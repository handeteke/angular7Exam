import { Component, OnInit, Input, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Product } from '../shared/product';

import { LoginService } from '../services/login.service';

import { assertDataInRangeInternal } from '@angular/core/src/render3/util';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SESSION_STORAGE, StorageService } from 'angular-webstorage-service';
import { AlertsService } from 'angular-alert-module';

export interface DialogData {
  product: Product;
}

@Component({
  selector: 'app-productdetail',
  templateUrl: './productdetail.component.html',
  styleUrls: ['./productdetail.component.scss']
})
export class ProductdetailComponent implements OnInit {

  addToCartForm: FormGroup;
  product;
  usercopy = null;
  errMess;
  disabled = true;

  constructor(private fb: FormBuilder,
    private loginService: LoginService,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    @Inject('BaseURL') private BaseURL,
    public dialogRef: MatDialogRef<ProductdetailComponent>,
    @Inject(SESSION_STORAGE) private storage: StorageService,
    private alerts: AlertsService) {

    this.createForm();
    this.product = this.data;
    console.log(this.data)
    console.log('this.storage.get(user)');
    console.log(this.storage.get('user'));
  }

  ngOnInit() {
    this.loginService.getUser(this.storage.get('user').id).subscribe((user) => {
      this.usercopy = user
      
    }, (errmess) => {
      this.errMess = <any>errmess
      console.log(errmess)
    });

    this.alerts.setDefaults('timeout',5);
  }

  createForm() {
    this.addToCartForm = this.fb.group({
      amount: [0, [Validators.required]],
    });
  }

  onSubmit() {
    if(this.addToCartForm.controls.amount.value > 0){
      console.log('this.addToCartForm.controls.amount.value: ', this.addToCartForm.controls.amount.value);
      this.product.amount = this.addToCartForm.controls.amount.value;
      console.log('product: ', this.product);

      let index;
      let found = false;
      for(let p of this.usercopy.cart){
        if(p.id == this.product.id){
          p.amount = p.amount + this.addToCartForm.controls.amount.value;
          found = true;
        }
      }
      if(!found){
        this.product.amount = this.addToCartForm.controls.amount.value;
        this.usercopy.cart.push(this.product)
      }

      this.usercopy.save()
        .subscribe(user => { console.log(user); });
      this.storage.set('user', this.usercopy);
      this.dialogRef.close();
    }else{
      this.alerts.setMessage('Please enter a valid amount','warn');
    }
    this.addToCartForm.reset({
      amount: 0,
    });
    
  }

}
