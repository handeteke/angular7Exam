import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CategoryService } from '../services/category.service'
import { Product } from '../shared/product';
import { SESSION_STORAGE, StorageService } from 'angular-webstorage-service';
import { ProductdetailComponent } from '../productdetail/productdetail.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-searchresult',
  templateUrl: './searchresult.component.html',
  styleUrls: ['./searchresult.component.scss'],
})
export class SearchresultComponent implements OnInit {

  result;
  products: Product[] = [];
  searchResult: Product[] = [];
  errMess;
  searchInput;

  constructor(private route: ActivatedRoute,
    private categoryService: CategoryService,
    @Inject('BaseURL') private BaseURL,
    @Inject(SESSION_STORAGE) private storage: StorageService,
    public dialog: MatDialog) {
    this.search();
  }

  ngOnInit() {
    this.searchResult = [];
    this.searchInput = this.route.snapshot.params['searchInput']
  }


  ngAfterViewInit() {
    if (this.searchInput !== this.route.snapshot.params['searchInput']) {
      console.log("değişti")
      this.search();
    }
  }

  search() {
    this.products = [];
    this.categoryService.getCategories()
      .subscribe(cats => {
        this.filterProducts(cats);
      }, errmess =>
          this.errMess = <any>errmess.message
      );
  }

  filterProducts(cats) {
    for (let cat of cats) {
      if (cat.products.length > 0) {
        for (let p of cat.products) {
          this.products.push(p);
        }
      }
    }
    if (!this.products) {
      this.searchResult = null;
    } else {
      let value = this.route.snapshot.params['searchInput'];
      if (value) {
        value = value.toLowerCase();
        this.searchResult = this.products.filter(function (item) {
          return JSON.stringify(item).toLowerCase().includes(value);
        });

      } else {
        this.searchResult = null;
      }
      console.log(this.searchResult)
    }
  }

  openProductDetailForm(product) {

    console.log('this.storage.get(user)', this.storage.get('user'));

    if (this.storage.get('user')) {
      const dialogRef = this.dialog.open(ProductdetailComponent, { width: '300px', height: '500px', data: product });
      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
      });
    }

  }
}
