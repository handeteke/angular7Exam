import { Injectable } from '@angular/core';
import { Category } from '../shared/category'
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';

import { map, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { baseURL } from '../shared/baseurl';

import { ProcessHTTPMsgService } from './process-httpmsg.service';
import { Restangular } from 'ngx-restangular';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  constructor(private http: HttpClient,
    private processHTTPMsgService: ProcessHTTPMsgService,
    private restangular: Restangular) { }

  getCategories(): Observable<Category[]> {
    return this.restangular.all('categories').getList();
  }

  getCategory(id: number): Observable<Category> {
    return this.restangular.one('categories', id).get();
  }

  getCategoryIds(): Observable<number[] | any> {
    return this.getCategories()
      .pipe(map(categories => categories.map(category => category.id)),
        catchError(error => error));
  }



}
