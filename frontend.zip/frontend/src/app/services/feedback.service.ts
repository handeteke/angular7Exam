import { Injectable } from '@angular/core';

import { Feedback } from '../shared/feedback'
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';

import { map, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { baseURL } from '../shared/baseurl';

import { ProcessHTTPMsgService } from './process-httpmsg.service';
import { Restangular } from 'ngx-restangular';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  constructor(private http: HttpClient, 
    private processHTTPMsgService: ProcessHTTPMsgService,
    private restangular: Restangular) { }

    getFeedbacks(): Observable<Feedback[]> {
      return this.restangular.all('feedbacks').getList();
    }

    postFeedback(fb:Feedback): Observable<any> {
      return this.restangular.all('feedbacks').post(fb);
    }
}
