import { Injectable } from '@angular/core';

import { User } from '../shared/user'
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';

import { map, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { baseURL } from '../shared/baseurl';

import { ProcessHTTPMsgService } from './process-httpmsg.service';
import { Restangular } from 'ngx-restangular';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient, private processHTTPMsgService: ProcessHTTPMsgService,
    private restangular: Restangular) { }


  getUsers(): Observable<User[]> {
    return this.restangular.all('users').getList();
  }

  getUser(id: number): Observable<User> {
    return this.restangular.one('users', id).get();
  }

}

