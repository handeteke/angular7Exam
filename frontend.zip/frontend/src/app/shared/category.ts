import {Product} from './product';

export class Category {
    id: number;
    name: string;
    image: string;
    description: string;
    products: Product[];
}