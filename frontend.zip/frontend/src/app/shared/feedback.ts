import { User } from "./user";

export class Feedback {
    id : number;
    from: User;
    telnum: string;
    message: string;
};

export const ContactType = ['None', 'Tel', 'Email'];