export class Product {
    id: number;
    name: string;
    brand: string;
    price: number;
    unit: string;
    amount: number;
    image: string;
    description: string;
}