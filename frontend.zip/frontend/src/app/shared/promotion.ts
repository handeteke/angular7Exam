export class Promotion {
    id: number;
    name: string;
    image: string;
    label: string;
    ratio: string;
    category: string;
    featured: boolean;
    description: string;
}