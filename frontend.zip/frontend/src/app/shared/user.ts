import {Product} from './product';

export class User {
    id: number;
    username: string;
    password: string;
    email: string;
    cart: Product[];
    formerOrders: Product[];
}